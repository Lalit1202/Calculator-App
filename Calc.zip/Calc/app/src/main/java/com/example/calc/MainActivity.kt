package com.example.calc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {
    private var strNumber = StringBuilder()
    private lateinit var tvDisplay: TextView
    private lateinit var result: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvDisplay=findViewById(R.id.eval)
        result = findViewById(R.id.result)
        btone.setOnClickListener { strNumber.append("1")
        tvDisplay.text = strNumber}
        bttwo.setOnClickListener { strNumber.append("2")
            tvDisplay.text = strNumber}
        btthree.setOnClickListener { strNumber.append("3")
            tvDisplay.text = strNumber}
        btfour.setOnClickListener { strNumber.append("4")
            tvDisplay.text = strNumber}
        btfive.setOnClickListener { strNumber.append("5")
            tvDisplay.text = strNumber}
        btsix.setOnClickListener { strNumber.append("6")
            tvDisplay.text = strNumber}
        btseven.setOnClickListener { strNumber.append("7")
            tvDisplay.text = strNumber}
        bteight.setOnClickListener { strNumber.append("8")
            tvDisplay.text = strNumber}
        btnine.setOnClickListener { strNumber.append("9")
            tvDisplay.text = strNumber}
        btzero.setOnClickListener { if(strNumber.toString()=="0" || strNumber.toString()==""){strNumber.delete(0,strNumber.length)
            tvDisplay.text="0"
            }
            else{strNumber.append("0")
            tvDisplay.text = strNumber} }
        btop.setOnClickListener {
            strNumber.append("(")
            tvDisplay.text = strNumber}
        btcls.setOnClickListener { strNumber.append(")")
            tvDisplay.text = strNumber}
        btplus.setOnClickListener {
            if(strNumber.toString() ==""){
                strNumber.append("0+")

            }
            if(strNumber.last()=='+' || strNumber.last()=='-' || strNumber.last()=='/' || strNumber.last()=='x' )
            {
                strNumber.replace(strNumber.lastIndex,strNumber.lastIndex+1,"+")
                tvDisplay.text=strNumber
            }
            else{
            strNumber.append("+")
            tvDisplay.text = strNumber}}

        btminus.setOnClickListener {
            if(strNumber.toString() ==""){
                strNumber.append("0-")

            }
            if(strNumber.last()=='+' || strNumber.last()=='-' || strNumber.last()=='/' || strNumber.last()=='x' )
            {
                strNumber.replace(strNumber.lastIndex,strNumber.lastIndex+1,"-")
                tvDisplay.text=strNumber
            }
            else{
            strNumber.append("-")
            tvDisplay.text = strNumber}}
        btmultiply.setOnClickListener {
            if(strNumber.toString() ==""){
                strNumber.append("0x")

            }
            if(strNumber.last()=='+' || strNumber.last()=='-' || strNumber.last()=='/' || strNumber.last()=='x' )
            {
                strNumber.replace(strNumber.lastIndex,strNumber.lastIndex+1,"x")
                tvDisplay.text=strNumber
            }
            else{
            strNumber.append("x")
            tvDisplay.text = strNumber}}
        btdivide.setOnClickListener {
            if(strNumber.toString() ==""){
                strNumber.append("0/")

            }
            if(strNumber.last()=='+' || strNumber.last()=='-' || strNumber.last()=='/' || strNumber.last()=='x' )
            {
                strNumber.replace(strNumber.lastIndex,strNumber.lastIndex+1,"/")
                tvDisplay.text=strNumber
            }
            else{
            strNumber.append("/")
            tvDisplay.text = strNumber}}

        btdel.setOnClickListener {
            if(strNumber.isNotEmpty())
            {
                strNumber.setLength(strNumber.length-1)
                tvDisplay.text = strNumber}
            if(strNumber.toString() == "")
            {
                tvDisplay.text ="0"
            }
            }


        btclr.setOnClickListener { strNumber.delete(0,strNumber.length)
            tvDisplay.text = "0"}


        btequal.setOnClickListener {
            if(strNumber.toString().contentEquals("()")){result.text = "Error"
                tvDisplay.text = "Error"
                strNumber.delete(0,strNumber.length)}
            if(strNumber.toString() != ""){result.text = evaluate(strNumber.toString()).toString()} }
    }
   companion object fun evaluate(expression: String): Double{

        var tokens: CharArray = expression.toCharArray()
        var len: Int = tokens.size
        var values: Stack<Double> = Stack()
        var ops: Stack<Char> = Stack()
        var j: Int = 0

        while(j < len )
        {
            if(tokens[j]== ' ')
                continue

            if(tokens[j]>='0' && tokens[j]<='9')
                {
                    var sbuf= StringBuffer()

                    while(j< len && tokens[j]>='0' && tokens[j]<='9')
                    {


                        sbuf.append(tokens[j++])
                    }
                    values.push(sbuf.toString().toDouble())

                   j--
                }

            else if(tokens[j] == '(')
                ops.push(tokens[j])
            else if(tokens[j] == ')')
            {
                while (ops.peek() != '(')
                    values.push(applyOp(ops.pop(),values.pop(),values.pop()))

                ops.pop()
            }

            else if(tokens[j] == '+' || tokens[j] == '-' || tokens[j] == 'x' || tokens[j] == '/')
            {
                while (!ops.empty() && hasPrecedence(tokens[j],ops.peek()))
                    values.push(applyOp(ops.pop(),values.pop(),values.pop()))

                ops.push(tokens[j])
            }
            j++



        }
        while (!ops.empty() && values.size>1)
            values.push(applyOp(ops.pop(),values.pop(),values.pop()))

        return values.pop()


    }

    fun hasPrecedence(op1: Char,op2: Char): Boolean{
        if(op2 == '(' || op2 == ')')
            return false
        if((op1 == 'x' || op1 == '/' ) && (op2 == '+' || op2 == '-'))
            return false
        else
            return true
     }

      fun applyOp(op: Char,b: Double, a: Double ): Double {
          when(op){

              '+' ->if(b==null)
              {
                 return a+0
              }
              else
                  return a+b
              '-' -> if(b==null)
              {
                  return a-0
              }
              else
                  return a-b
              'x' -> if(b==null)
              {
                  return a*1
              }
              else
                  return a*b
              '/' -> if(b==0.0)
              {
                  Toast.makeText(this,"Invalid Input",Toast.LENGTH_SHORT).show()
                  tvDisplay.text = "Error"
                  result.text ="Error"
                  strNumber.delete(0,strNumber.length)
              }
              else if(b==null)
              {
                  return a/1
              }
              else
              {
                  return a/b
              }





          }
          return 0.0


    }


}



